self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7e8b1621d8681a6e134c921daeb20134",
    "url": "/index.html"
  },
  {
    "revision": "a41af31275f2a26761be",
    "url": "/static/css/2.b0bb7f2c.chunk.css"
  },
  {
    "revision": "8f085e9b8064e21b72d0",
    "url": "/static/css/main.69f39db5.chunk.css"
  },
  {
    "revision": "a41af31275f2a26761be",
    "url": "/static/js/2.01800481.chunk.js"
  },
  {
    "revision": "8f085e9b8064e21b72d0",
    "url": "/static/js/main.586ad54e.chunk.js"
  },
  {
    "revision": "1b8fa809f9ee3518ccfb",
    "url": "/static/js/runtime-main.cb1dbb88.js"
  },
  {
    "revision": "d1182cbc107326d85ab7ebc726645916",
    "url": "/static/media/Assiette-Adana.d1182cbc.png"
  },
  {
    "revision": "54df53e002f1ae662d7e58e2b832182f",
    "url": "/static/media/Assiette-Merguez.54df53e0.png"
  },
  {
    "revision": "c3208d3b0cda84027cdc3f60bdfaa5a3",
    "url": "/static/media/Assiette-Steack.c3208d3b.png"
  },
  {
    "revision": "e5ccd08ce25ea2a10c609c14bb41520c",
    "url": "/static/media/assiette-brochette-poulet.e5ccd08c.jpg"
  },
  {
    "revision": "7fec23eeaf87335c221ef351c3bacf2a",
    "url": "/static/media/assiette-chicken-chika.7fec23ee.jpg"
  },
  {
    "revision": "c7c2feabd60629bfa6e55721eddd0058",
    "url": "/static/media/assiette-cotelettes.c7c2feab.png"
  },
  {
    "revision": "3830afa4876eeb6fab3482546c98874e",
    "url": "/static/media/assiette-grillade-mixte.3830afa4.jpg"
  },
  {
    "revision": "0a0d21a67699108db2767f3cfe9a768f",
    "url": "/static/media/assiette-kebab.0a0d21a6.jpg"
  },
  {
    "revision": "b4eed4126b8df31ddc04f54704505565",
    "url": "/static/media/assiette-kefta.b4eed412.png"
  },
  {
    "revision": "1423ae695c8a5849014f1fa64a6930a0",
    "url": "/static/media/burger.1423ae69.jpg"
  },
  {
    "revision": "14711e7f9909cc0af97ded9134af340a",
    "url": "/static/media/chevron-next.14711e7f.svg"
  },
  {
    "revision": "3f222223b84aceaf10fa0c7ab3637dff",
    "url": "/static/media/chevron-prev.3f222223.svg"
  },
  {
    "revision": "cf41505e9d242e85de4ffb3a9655efde",
    "url": "/static/media/close.cf41505e.svg"
  },
  {
    "revision": "ee69d7f2bd8920c875a029919a5de085",
    "url": "/static/media/kebab2.ee69d7f2.jpg"
  },
  {
    "revision": "57afd21f8ba1f06be8f13b4eed7af1c8",
    "url": "/static/media/kebabSandwich.57afd21f.svg"
  },
  {
    "revision": "a00b5302a6e123b25c8514d432ad9159",
    "url": "/static/media/location.a00b5302.svg"
  },
  {
    "revision": "f4b7d0becccf4ccdbcd97c761ba73f7c",
    "url": "/static/media/logo.f4b7d0be.svg"
  },
  {
    "revision": "bfc51e798de9ef914e36a8f6379baa16",
    "url": "/static/media/nav-lines.bfc51e79.svg"
  },
  {
    "revision": "c3e07b9502f32aa2ac0bd3abb0a7c96f",
    "url": "/static/media/plate.c3e07b95.svg"
  },
  {
    "revision": "71139824e66b73041a46095c89fde329",
    "url": "/static/media/sandwich-adana.71139824.png"
  },
  {
    "revision": "f828d2680dc807a8818fd5b51a5b698e",
    "url": "/static/media/sandwich-brochettes-agneau.f828d268.png"
  },
  {
    "revision": "fc39c2a0bb3768ef758d938a2e143408",
    "url": "/static/media/sandwich-brochettes-poulet.fc39c2a0.jpg"
  },
  {
    "revision": "45720c0d6325962d2f1c12a896d0c4b4",
    "url": "/static/media/sandwich-chicken-chika.45720c0d.jpg"
  },
  {
    "revision": "9ae2dd7f392c395bbb4c8d0075288349",
    "url": "/static/media/sandwich-kebab.9ae2dd7f.jpg"
  },
  {
    "revision": "a666a7ff58c2150d47740f8d7d70f6ac",
    "url": "/static/media/sandwich-kefta.a666a7ff.png"
  },
  {
    "revision": "bb61f4af13fa3e50f39a14ff3045fb46",
    "url": "/static/media/sandwich-merguez.bb61f4af.jpg"
  },
  {
    "revision": "aff390868fb8ec4a4dbf8071202b3c49",
    "url": "/static/media/sandwich-special.aff39086.jpg"
  },
  {
    "revision": "a33a3228dc1f8e71f7b8e6046ca5ede5",
    "url": "/static/media/sandwich-steack-fromage.a33a3228.jpg"
  },
  {
    "revision": "8e7190db3f489897ccf67261ea3407ea",
    "url": "/static/media/sandwichKebab.8e7190db.png"
  },
  {
    "revision": "c360b5de023ab7551a8068d33f8d7841",
    "url": "/static/media/tea-cup.c360b5de.svg"
  },
  {
    "revision": "902c218e8588035b365fdb6b45039f90",
    "url": "/static/media/toast.902c218e.svg"
  },
  {
    "revision": "60fa8ab5d478c0f75625d8b0cef7b1a0",
    "url": "/static/media/watch.60fa8ab5.svg"
  }
]);